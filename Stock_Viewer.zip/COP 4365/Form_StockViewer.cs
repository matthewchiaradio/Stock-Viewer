﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms.VisualStyles;
using static System.Net.Mime.MediaTypeNames;

namespace Stock_Viewer
{
    public partial class Form_StockViewer : Form
    {
        List<smartCandlestick> listofCandleSticks = new List<smartCandlestick>(1024); // List of candlesticks
        BindingList<smartCandlestick> boundCandleSticks = null; // Binding list
        List<String> listofPatterns = new List<String>(); // List of patterns for combobox
        string filename; // Input filename

        public Form_StockViewer()
        {
            InitializeComponent();
        }

        // Initialize new form with given path and date range
        public Form_StockViewer (string stockPath, DateTime start, DateTime end)
        {
            InitializeComponent (); // Initialize new form

            startTimePicker.Value = start; // Get start date
            endTimePicker.Value = end; // Get end date

            listofCandleSticks = readAndDisplayStock(stockPath); // Read file and return all candlesticks

            update(); // Update chart
            addAnotations(); // Add annotations
        }

        // Read file with given path and update chart
        List<smartCandlestick> readAndDisplayStock(string path)
        {
            List<smartCandlestick> l = goReadFile(path); // Get list of smartcandlesticks
            Dictionary<string, Recognizer> recognizers = createRecognizer(); // Create dictionary of recognizers
            initializeComboBox(recognizers); // Initialize combobox based upon the dictionary of recognizers
            recognizeAll(recognizers, listofCandleSticks); // Call recognizers to compute patterns
            update(); // Update chart
            return l; // Return list of smart candlesticks
        }

        private void button_ChooseStock_Click(object sender, EventArgs e) // Pick a Stock button
        {
            openFileDialog_TickerChooser.ShowDialog(); // Open file directory
        }

        /// <summary>
        /// Create a new form for every file selected and update the charts accordingly
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileDialog_TickerChooser_FileOk(object sender, CancelEventArgs e) 
        {
            int n = openFileDialog_TickerChooser.FileNames.Count(); // n is the number of files selected
            DateTime startDate = startTimePicker.Value; // Get start date
            DateTime endDate = endTimePicker.Value; // Get end date

            // For each file selected, initiate new form and update chart
            for (int i = 0; i < n; i++) 
            {
                string pathName = openFileDialog_TickerChooser.FileNames[i]; // Get path
                string ticker = Path.GetFileNameWithoutExtension(pathName); // Get file name without extension
                Form_StockViewer form_StockViewer; // Decalre new form

                if (i == 0) // Parent form
                {
                    form_StockViewer = this; // Parent form, so keep form the same
                    readAndDisplayStock(pathName); // Read and display stock
                    form_StockViewer.Text = "Parent: " + ticker; // Name of form
                }
                else // Child form
                {
                    form_StockViewer = new Form_StockViewer(pathName, startDate, endDate); // Child form, initilize new form
                    readAndDisplayStock(pathName); // Read and display stock
                    form_StockViewer.Text = "Child: " + ticker; // Name of form
                } 
                form_StockViewer.Show(); // Show form
                form_StockViewer.BringToFront(); // Bring form to the front
            }

            filename = openFileDialog_TickerChooser.FileName; // Set file name to the filename of selected file
            boundCandleSticks = filterCandleSticks(listofCandleSticks, startDate, endDate);
            update(); // update data and charts
            addAnotations(); // add annotations
        }

        /// <summary>
        /// Retrieves the data stored in the file chosen by the user and stores it
        /// to the list of all candlesticks, Style
        /// </summary>
        /// <param name="filename"> File name to be read from</param> 
        /// <returns> List of all candlesticks </returns> 
        private List<smartCandlestick> goReadFile(string filename)
        { 
            string referenceString = "Date,Open,High,Low,Close,Adj Close,Volume"; // Column names of input file

            using (StreamReader sr = new StreamReader(filename)) // Read from the file
            {
                listofCandleSticks.Clear(); // Clear list of candlesticks

                string line = sr.ReadLine(); // Get first line of file (column names)
                if (line == referenceString) // if columns of input file is the same as what we are looking for
                {
                    while((line = sr.ReadLine()) != null) // Read the next line and ensure it is not null
                    {
                        smartCandlestick cs = new smartCandlestick(line); // Initiate candlestick object
                        listofCandleSticks.Add(cs); // Add new candlestick to list of candlesticks
                    }
                }
                else
                {
                    Text = "Bad File" + filename; // File columns are not equal to the reference string
                }
            }
            return listofCandleSticks;
        }

        /// <summary>
        /// Filters the data that will be displayed in the grid view and 
        /// charts according to the range of the time pickers
        /// </summary>
        /// <param name="listofCandleSticks"> List of all candlesticks</param>
        /// <param name="startDate"> Start date </param>
        /// <param name="endDate"> End Date </param>
        /// <returns>Binding list of filtered candlestick</returns>
        BindingList<smartCandlestick> filterCandleSticks(List<smartCandlestick> listofCandleSticks, DateTime startDate, DateTime endDate)
        {

            List<smartCandlestick> selectedCandleStick = new List<smartCandlestick>(listofCandleSticks.Count()); // Create a list of type CandleStick with the size of all Candlesticks
            for (int i = 0; i < listofCandleSticks.Count(); i++) // Iterate through all candlesticks
            {
                smartCandlestick scs = listofCandleSticks[i]; // Current candlstick
                //smartCandlestick scs = new smartCandlestick(cs);

                if (startDate <= scs.date && scs.date <= endDate) // if current candlestick is past start date but before end date
                    selectedCandleStick.Add(scs); // add candlestick to new list

                if (endDate <= scs.date) // if end date is before the current candlestick's date
                    break; // since we are past the end date, exit loop since candlesticks are ordered by date
            }
            return new BindingList<smartCandlestick>(selectedCandleStick);
        }
        
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) {} // start date (time picker on the left)

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e) {} // end date (time picker on the right)

        private void button_Update_Click(object sender, EventArgs e) // Update button
        {
            update(); // update data and charts
            addAnotations(); // Add annotations
        }

        /// <summary>
        /// Adjusts the chart according to the highest value and lowest value
        /// </summary>
        /// <param name="boundCandleSticks">Binding list of candlesticks</param>
        private void normalizeChart(BindingList<smartCandlestick> boundCandleSticks)
        {
            decimal min = 1000000; // Higher than any possible value
            decimal max = 0; // Lower than any possible value
            decimal buffer; // Extra space to add

            for (int i = 0; i < boundCandleSticks.Count(); i++) // Iterate through selected candlesticks
            {
                smartCandlestick scs = boundCandleSticks[i]; // Current candlestick

                if(scs.low < min) // if lowest value of current candlestick is less than the current min
                    min = scs.low; // Update min
                if(scs.high > max) // if highest value of current candlestick is greater than the current max
                    max = scs.high; // Update max
            }

            buffer = (max - min) * (decimal)0.02; // Set buffer to the range * 2%
            min = min - buffer; // Add whitespace below candlesticks
            max = max + buffer; // Add whitespace above candlesticks

            chart_CandleSticks.ChartAreas["ChartArea_OHLC"].AxisY.Minimum = (int)min; // Update min value of chart
            chart_CandleSticks.ChartAreas["ChartArea_OHLC"].AxisY.Maximum = (int)max; // Update max value of chart
        }

        /// <summary>
        /// Displays the data in the binding list
        /// </summary>
        /// <param name="boundCandleSticks">Binding list of candlesticks</param>
        private void displayCandleSticks(BindingList<smartCandlestick> boundCandleSticks)
        {
            chart_CandleSticks.DataSource = boundCandleSticks; // set chart's data source to binding list
            chart_CandleSticks.DataBind(); // bind data to chart
        }

        /// <summary>
        /// Updates chart and data view by filtering, displaying, and normalizing the chart
        /// </summary>
        private void update()
        {
            filterCandleSticks(); // filter candlesticks
            normalizeChart(); // adjust chart
            displayCandleSticks(); // display candsticks
        }

        /// <summary>
        /// Initialize the combo box by getting all the patterns from the smartcandlestick class
        /// </summary>
        private void initializeComboBox(Dictionary<string, Recognizer> recognizers)
        {
            listofPatterns = recognizers.Keys.ToList(); // Get keys

            combobox_Patterns.DataSource = listofPatterns; // Set data source
            combobox_Patterns.ValueMember = null;
            combobox_Patterns.DisplayMember = "Name"; // Display patterns
        }

        /// <summary>
        /// Clear and update all anotations to the chart
        /// </summary>
        private void addAnotations()
        {
            chart_CandleSticks.Annotations.Clear(); // Clear previous annotations
            int track = 0; // When data point is not found
            foreach (DataPoint dp in chart_CandleSticks.Series["Series_OHLC"].Points) // For each candlestick in the chart
            {
                smartCandlestick scs = new smartCandlestick(); // Initialize smartcandlestick
                for (int i = 0; i < boundCandleSticks.Count(); i++) // Find correlating candlestick to data point
                {
                    if (dp.XValue == boundCandleSticks[i].date.ToOADate()) // Correlating candlestick
                    {
                        track = 1; // Found candlestick
                        scs = boundCandleSticks[i]; // Save candlestick of interest
                        break; // Stop searching
                    }
                }

                if (track == 0) // Candlestick not found
                {
                    continue; // Skip annotation for that candlestick
                }

                if (scs.patterns[combobox_Patterns.Text] == true) // If the pattern is true, add annotation
                {
                    ArrowAnnotation annotation = new ArrowAnnotation(); // Initialize annotation
                    annotation.AxisX = chart_CandleSticks.ChartAreas["ChartArea_OHLC"].AxisX; // Set x axis to chart
                    annotation.AxisY = chart_CandleSticks.ChartAreas["ChartArea_OHLC"].AxisY; // Set y axis to chart
                    annotation.AnchorDataPoint = dp; // Anchor annotation at data point
                    annotation.ArrowSize = 2; // Set arrow size
                    annotation.Width = 1; // Set width
                    annotation.Height = 0.3; // Set height
                    annotation.Visible = true; // Make sure they are visible
                    annotation.BringToFront(); // Make sure they are in the front
                    chart_CandleSticks.Annotations.Add(annotation); //  Add annotation to chart
                }
            }
        }

        /// <summary>
        /// This method creates a dictionary of all recognizers with a string as the key and the recognizer as the value
        /// </summary>
        /// <returns>Dictionary of all recognizers</returns>
        Dictionary<string, Recognizer> createRecognizer()
        {
            Dictionary<string, Recognizer> recognizers = new Dictionary<string, Recognizer>(); // Declare dictionary 
            recognizers["Bullish Engulfing"] = new Recognizer_BullishEngulfing(); // Add bullish engulfing recognizer to dictionary
            recognizers["Bearish Engulfing"] = new Recognizer_BearishEngulfing(); // Add bearish engulfing recognizer to dictionary
            recognizers["Bullish Harami"] = new Recognizer_BullishHarami(); // Add bullish harami recognizer to dictionary
            recognizers["Bearish Harami"] = new Recognizer_BearishHarami(); // Add bearish harami recognizer to dictionary
            recognizers["Peak"] = new Recognizer_Peak(); // Add peak recognizer to dictionary
            recognizers["Valley"] = new Recognizer_Valley(); // Add valley recognizer to dictionary
            recognizers["Bearish"] = new Recognizer_Bearish(); // Add bearish recognizer to dictionary
            recognizers["Bullish"] = new Recognizer_Bullish(); // Add bullish recognizer to dictionary
            recognizers["Doji"] = new Recognizer_Doji(); // Add doji recognizer to dictionary
            recognizers["DragonflyDoji"] = new Recognizer_DragonflyDoji(); // Add dragonfly doji recognizer to dictionary
            recognizers["GravestoneDoji"] = new Recognizer_GravestoneDoji(); // Add gravestone doji recognizer to dictionary
            recognizers["Hammer"] = new Recognizer_Hammer(); // Add hammer recognizer to dictionary
            recognizers["Marubozu"] = new Recognizer_Marubozu(); // Add marubozu recognizer to dictionary
            recognizers["Neutral"] = new Recognizer_Neutral(); // Add neutral recognizer to dictionary

            return recognizers; // Return dictionary of recognizers 
        }

        /// <summary>
        /// This method calls every recognizer to compute patterns for each smart candlestick
        /// </summary>
        /// <param name="recognizers"></param>
        /// <param name="list"></param>
        private void recognizeAll(Dictionary<string, Recognizer> recognizers, List<smartCandlestick> list)
        {
            foreach (var r in recognizers) // For every recognizer (r is a key value pair object)
            {
                for (int i = 0; i < list.Count; i++) // For each smart candlestick
                {
                    r.Value.Recognize(list, i); // Compute pattern of recognizer for smart candlestick at index i
                }
            }
        }

        // Version 2
        private void goReadFile()
        {
            listofCandleSticks = goReadFile(filename); // Sets listofCandleSticks to a list of all candlesticks
        }

        // Version 2
        private void filterCandleSticks()
        {
            boundCandleSticks = filterCandleSticks(listofCandleSticks, startTimePicker.Value, endTimePicker.Value); // Set bindling list to filtered list
        }

        // Version 2
        private void displayCandleSticks()
        {
            displayCandleSticks(boundCandleSticks); // Call displayCandleSticks with parameter
        }

        // Version 2
        private void normalizeChart()
        {
            normalizeChart(boundCandleSticks); // Call normalizeChart with parameter
        }

        private void Form_StockViewer_Load(object sender, EventArgs e) {}

        private void candleStickBindingSource_CurrentChanged(object sender, EventArgs e)
        {
        }

        private void combobox_Patterns_SelectedIndexChanged(object sender, EventArgs e)
        {
            addAnotations(); // Update annotations
        }
    }
}
