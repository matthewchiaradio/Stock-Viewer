﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_Viewer
{
    // smartCandlestick class inherited from CandleStick class
    internal class smartCandlestick : CandleStick 
    {
        // Extra Properties
        public decimal range { get; set; } // Range of candlestick
        public decimal topPrice { get; set; } // Maximum between open and close
        public decimal bottomPrice { get; set; } // Minimum between open and close
        public decimal bodyRange { get; set; } // Range of the body 
        public decimal upperTail {  get; set; } // Size of uppper tail
        public decimal lowerTail { get; set; } // Size of lower tail

        public Dictionary<string, bool> patterns = new Dictionary<string, bool>(); // Stores pattern properties

        /// <summary>
        /// Smart Candlestick constructor
        /// </summary>
        /// <param name="csvData">Row of data</param>
        public smartCandlestick(string csvData) : base(csvData)
        {
            computeExtraProperties(); // Compute extra properties
        }

        public smartCandlestick(CandleStick candlestick)
        {
            this.open = candlestick.open; // Set open
            this.close = candlestick.close; // Set close
            this.high = candlestick.high; // Set high
            this.low = candlestick.low; // Set low
            this.volume = candlestick.volume; // Set volume
            this.date = candlestick.date; // Set date

            computeExtraProperties(); // Compute extra properties
        }

        public smartCandlestick()
        {
            this.open = 0; // Set open
            this.close = 0; // Set close
            this.high = 0; // Set high
            this.low = 0; // Set low
            this.volume = 0; // Set volume
            this.date = DateTime.Now; // Set date

            computeExtraProperties(); // Compute extra properties
        }

        /// <summary>
        /// Compute the extra properties unique to smartCandlestick
        /// </summary>
        public void computeExtraProperties()
        {
            range = high - low; // range of candlestick

            topPrice = Math.Max(open, close); // top price is the maximum between the open and the close

            bottomPrice = Math.Min(open, close); // bottom price is the minimum between the open and the close

            bodyRange = topPrice - bottomPrice; // range of the body

            upperTail = high - topPrice; // range of the upper tail

            lowerTail = bottomPrice - low; // range of the lower tail
        }
    }
}