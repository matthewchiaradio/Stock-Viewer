﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_Viewer
{

    internal class Recognizer_BullishHarami : Recognizer // Inherited from recognizer
    {
        public Recognizer_BullishHarami() : base("Bullish Harami", 2) { } // Set pattern name and pattern length

        public override bool Recognize(List<smartCandlestick> lscs, int index)
        {
            if (index < 1 || index > lscs.Count) // Check if index is valid for pattern
            {
                lscs[index].patterns.Add(patternName, false); // Invalid index so pattern is false
                return false;
            }

            smartCandlestick current = lscs[index]; // Current candlestick
            smartCandlestick previous = lscs[index - 1]; // Previous candlestick

            bool exists = current.patterns.TryGetValue(patternName, out bool r); // Check if pattern is already calculated

            if (!exists) // If pattern doesn't exist, calculate it
            {
                r = previous.close < previous.open && current.topPrice < previous.open && current.bottomPrice > previous.close &&
                    current.close > current.open;
                current.patterns.Add(patternName, r); // Add pattern to dictionary in the smart candlestick
            }

            return r;
        }
    }
}
