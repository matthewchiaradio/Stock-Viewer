﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Viewer
{
    abstract class Recognizer
    {
        public string patternName; // Pattern name
        public int patternLength; // Pattern length (single or multi candlestick pattern)

        public abstract bool Recognize(List<smartCandlestick> lscs, int index);

        protected Recognizer (string pN, int pL)
        {
            patternName = pN; // Set pattern name 
            patternLength = pL; // Set pattern length
        }
    }
}
