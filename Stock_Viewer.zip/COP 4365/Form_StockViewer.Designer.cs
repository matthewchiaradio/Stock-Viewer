﻿namespace Stock_Viewer
{
    partial class Form_StockViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.openFileDialog_TickerChooser = new System.Windows.Forms.OpenFileDialog();
            this.startTimePicker = new System.Windows.Forms.DateTimePicker();
            this.endTimePicker = new System.Windows.Forms.DateTimePicker();
            this.chart_CandleSticks = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button_ChooseStock = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.combobox_Patterns = new System.Windows.Forms.ComboBox();
            this.candleStickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.smartcandlestickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.chart_CandleSticks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.candleStickBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smartcandlestickBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog_TickerChooser
            // 
            this.openFileDialog_TickerChooser.Filter = "All|*.csv|Monthly|*_Month.csv|Weekly|*_Week.csv|Daily|*_Day.csv";
            this.openFileDialog_TickerChooser.Multiselect = true;
            this.openFileDialog_TickerChooser.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_TickerChooser_FileOk);
            // 
            // startTimePicker
            // 
            this.startTimePicker.Location = new System.Drawing.Point(12, 399);
            this.startTimePicker.Name = "startTimePicker";
            this.startTimePicker.Size = new System.Drawing.Size(200, 20);
            this.startTimePicker.TabIndex = 2;
            this.startTimePicker.Value = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.startTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // endTimePicker
            // 
            this.endTimePicker.Location = new System.Drawing.Point(588, 399);
            this.endTimePicker.Name = "endTimePicker";
            this.endTimePicker.Size = new System.Drawing.Size(200, 20);
            this.endTimePicker.TabIndex = 3;
            this.endTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // chart_CandleSticks
            // 
            chartArea1.AxisX.Title = "Date";
            chartArea1.AxisY.Title = "Price [$]";
            chartArea1.Name = "ChartArea_OHLC";
            chartArea2.AlignWithChartArea = "ChartArea_OHLC";
            chartArea2.AxisX.Title = "Date";
            chartArea2.AxisY.Title = "Volume";
            chartArea2.Name = "ChartArea_volume";
            this.chart_CandleSticks.ChartAreas.Add(chartArea1);
            this.chart_CandleSticks.ChartAreas.Add(chartArea2);
            this.chart_CandleSticks.Location = new System.Drawing.Point(12, 12);
            this.chart_CandleSticks.Name = "chart_CandleSticks";
            series1.ChartArea = "ChartArea_OHLC";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series1.CustomProperties = "PriceUpColor=Lime, PriceDownColor=Red";
            series1.Name = "Series_OHLC";
            series1.XValueMember = "Date";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series1.YValueMembers = "High, Low, Open, Close";
            series1.YValuesPerPoint = 4;
            series2.ChartArea = "ChartArea_volume";
            series2.Name = "Series_volume";
            series2.XValueMember = "Date";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Date;
            series2.YValueMembers = "Volume";
            this.chart_CandleSticks.Series.Add(series1);
            this.chart_CandleSticks.Series.Add(series2);
            this.chart_CandleSticks.Size = new System.Drawing.Size(776, 324);
            this.chart_CandleSticks.TabIndex = 4;
            // 
            // button_ChooseStock
            // 
            this.button_ChooseStock.Location = new System.Drawing.Point(343, 347);
            this.button_ChooseStock.Name = "button_ChooseStock";
            this.button_ChooseStock.Size = new System.Drawing.Size(120, 60);
            this.button_ChooseStock.TabIndex = 7;
            this.button_ChooseStock.Text = "Pick a Stock";
            this.button_ChooseStock.UseVisualStyleBackColor = true;
            this.button_ChooseStock.Click += new System.EventHandler(this.button_ChooseStock_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(343, 413);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(120, 60);
            this.button_Update.TabIndex = 8;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // combobox_Patterns
            // 
            this.combobox_Patterns.FormattingEnabled = true;
            this.combobox_Patterns.Location = new System.Drawing.Point(343, 497);
            this.combobox_Patterns.Name = "combobox_Patterns";
            this.combobox_Patterns.Size = new System.Drawing.Size(120, 21);
            this.combobox_Patterns.TabIndex = 9;
            this.combobox_Patterns.SelectedIndexChanged += new System.EventHandler(this.combobox_Patterns_SelectedIndexChanged);
            // 
            // candleStickBindingSource
            // 
            //this.candleStickBindingSource.DataSource = typeof(COP_4365.CandleStick);
            this.candleStickBindingSource.DataSource = typeof(Stock_Viewer.CandleStick);
            this.candleStickBindingSource.CurrentChanged += new System.EventHandler(this.candleStickBindingSource_CurrentChanged);
            // 
            // smartcandlestickBindingSource
            // 
            this.smartcandlestickBindingSource.DataSource = typeof(Stock_Viewer.smartCandlestick);
            // 
            // Form_StockViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 605);
            this.Controls.Add(this.combobox_Patterns);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_ChooseStock);
            this.Controls.Add(this.chart_CandleSticks);
            this.Controls.Add(this.endTimePicker);
            this.Controls.Add(this.startTimePicker);
            this.Name = "Form_StockViewer";
            this.Text = "Please Pick A Stock";
            this.Load += new System.EventHandler(this.Form_StockViewer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart_CandleSticks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.candleStickBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smartcandlestickBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog openFileDialog_TickerChooser;
        private System.Windows.Forms.BindingSource candleStickBindingSource;
        private System.Windows.Forms.DateTimePicker startTimePicker;
        private System.Windows.Forms.DateTimePicker endTimePicker;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart_CandleSticks;
        private System.Windows.Forms.Button button_ChooseStock;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.BindingSource smartcandlestickBindingSource;
        private System.Windows.Forms.ComboBox combobox_Patterns;
    }
}

