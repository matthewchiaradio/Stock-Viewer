﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Stock_Viewer
{
    internal class Recognizer_Marubozu : Recognizer
    {
        public Recognizer_Marubozu() : base("Marubozu", 1) { } // Sets pattern name and pattern length
        public override bool Recognize(List<smartCandlestick> lscs, int index)
        {
            smartCandlestick scs = lscs[index]; // Get candlestick at index

            bool exists = scs.patterns.TryGetValue(patternName, out bool r); // Check if pattern is already calculated

            if (!exists) // If it doesnt exist, calculate
            {
                r = scs.bodyRange == scs.range; // Marubozu
                lscs[index].patterns.Add(patternName, r); // Update smartcandlesticks
            }

            return r; // Return if Marubozu
        }
    }
}