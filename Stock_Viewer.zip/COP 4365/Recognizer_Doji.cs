﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stock_Viewer
{
    internal class Recognizer_Doji : Recognizer
    {
        public Recognizer_Doji() : base("Doji", 1) { } // Sets pattern name and pattern length
        public override bool Recognize(List<smartCandlestick> lscs, int index)
        {
            smartCandlestick scs = lscs[index]; // Get candlestick at index

            bool exists = scs.patterns.TryGetValue(patternName, out bool r); // Check if pattern is already calculated

            if (!exists) // If it doesnt exist, calculate
            {
                r = scs.high == scs.low; // Doji
                lscs[index].patterns.Add(patternName, r); // Update smartcandlesticks
            }

            return r; // Return if Doji
        }
    }
}
