﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Stock_Viewer
{
    internal class CandleStick
    {
        public decimal open { get; set; } // Open price
        public decimal high { get; set; } // Highest price
        public decimal low { get; set; } // Lowest price
        public decimal close { get; set; } // Close price
        public ulong volume { get; set; } // Volume
        public DateTime date { get; set; } // Date

        // This method converts data from csv file to candlestick
        public CandleStick (string rowOfData)
        {
            char[] separators = new char[] { ',', ' ', '"' }; // Seperators of the data
            string[] subs = rowOfData.Split(separators, StringSplitOptions.RemoveEmptyEntries); // split data at seperators and store to array, empty entries are not added

            string dateString = subs[0]; // get date string
            date = DateTime.Parse(dateString); // parse date

            decimal temp;
            bool success = decimal.TryParse(subs[1], out temp); // open is stored at index 1, try to parse
            if (success) open = temp; // if parsing was successful, save to open

            success = decimal.TryParse(subs[2], out temp); // high is stored at index 2, try to parse
            if (success) high = temp; // if parsing was successful, save to high

            success = decimal.TryParse(subs[3], out temp);  // low is stored at index 3, try to parse
            if (success) low = temp; // if parsing was successful, save to low

            success = decimal.TryParse(subs[4], out temp);  // close is stored at index 4, try to parse
            if (success) close = temp; // if parsing was successful, save to close

            ulong tempVolume;
            success = ulong.TryParse(subs[6], out tempVolume); // volume is stored at index 6, try to parse
            if (success) volume = tempVolume; // if parsing was successful, save to volume
        }

        /// <summary>
        /// Defualt constructor
        /// </summary>
        public CandleStick ()
        {
            open = 0;
            close = 0;
            high = 0;
            close = 0;
            volume = 0;
            date = DateTime.Now;
        }
    }
}